// Snippet: Policy Studio — host data-fetching layer (V4 APIs)
//
// Use alongside policy-studio-provider-host.tsx to wire the data queries
// that feed <PolicyStudio /> props.  This is the typical integration shape:
// parallel queries for the API detail + plans + plugin catalogs, memoized
// transforms, and a single loading/error gate before rendering the studio.
//
// Replace {PLACEHOLDERS} with your service calls and environment helpers.
// V2 APIs are NOT covered — they require a host-side adapter that maps
// pathOperator + pre/post to selectors + request/response phases.
// Set readOnly={true} on <PolicyStudio /> for V2 APIs.
//
// See Storybook "Policy Studio / PolicyStudio / InAppLayout" for the full shell.

import { useMemo } from 'react';
import type {
  ApiType,
  ConnectorInfo,
  Flow,
  Plan,
  Policy,
  SharedPolicyGroupPolicy,
} from '@gravitee/graphene-policy-studio';

// ── 1. Query key factory (adapt to your cache library) ─────────────────

export const policyStudioKeys = {
  all: ['policy-studio'] as const,
  api: (apiId: string) => [...policyStudioKeys.all, 'api', apiId] as const,
  plans: (apiId: string) => [...policyStudioKeys.all, 'plans', apiId] as const,
  policies: () => [...policyStudioKeys.all, 'policies'] as const,
  entrypoints: () => [...policyStudioKeys.all, 'entrypoints'] as const,
  endpoints: () => [...policyStudioKeys.all, 'endpoints'] as const,
  sharedPolicyGroups: () => [...policyStudioKeys.all, 'shared-policy-groups'] as const,
};

// ── 2. Connector info transforms ───────────────────────────────────────
// The studio needs ConnectorInfo[] built by joining the API's configured
// listeners / endpoint groups with the org-level plugin catalog.

interface PluginEntry {
  id: string;
  name: string;
  icon?: string;
  supportedModes: string[];
}

interface ApiDetail {
  type: ApiType;
  listeners?: { entrypoints?: { type: string }[] }[];
  endpointGroups?: { endpoints?: { type: string }[] }[];
  flows?: Flow[];
  flowExecution?: { mode: string; matchRequired?: boolean };
}

function buildEntrypointsInfo(api: ApiDetail, plugins: PluginEntry[]): ConnectorInfo[] {
  if (!api.listeners) return [];
  return api.listeners.flatMap((listener) =>
    (listener.entrypoints ?? []).map((ep) => {
      const plugin = plugins.find((p) => p.id === ep.type);
      return {
        type: ep.type,
        icon: plugin?.icon ?? 'gio:language',
        name: plugin?.name ?? ep.type,
        supportedModes: (plugin?.supportedModes ?? []) as ConnectorInfo['supportedModes'],
      };
    }),
  );
}

function buildEndpointsInfo(api: ApiDetail, plugins: PluginEntry[]): ConnectorInfo[] {
  if (!api.endpointGroups) return [];
  return api.endpointGroups.flatMap((group) =>
    (group.endpoints ?? []).map((ep) => {
      const plugin = plugins.find((p) => p.id === ep.type);
      return {
        type: ep.type,
        icon: plugin?.icon ?? 'gio:language',
        name: plugin?.name ?? ep.type,
        supportedModes: (plugin?.supportedModes ?? []) as ConnectorInfo['supportedModes'],
      };
    }),
  );
}

// ── 3. Aggregating hook ────────────────────────────────────────────────
// Fire all queries in parallel.  Policies, entrypoint plugins, endpoint
// plugins, and shared policy groups are org-scoped (long staleTime).
// API detail and plans are env+api scoped (shorter staleTime).

export function usePolicyStudioData(_apiId: string | undefined) {
  // {PARALLEL_QUERIES} — replace with your data-fetching library (e.g. useQuery).
  // You need six parallel fetches:
  //   1. API detail          (env-scoped)  → api type, listeners, endpointGroups, flows, flowExecution
  //   2. Published plans     (env-scoped)  → plan id, name, flows
  //   3. Policy catalog      (org-scoped)  → id, name, description, icon, category, flowPhaseCompatibility
  //   4. Entrypoint plugins  (org-scoped)  → id, name, icon, supportedModes
  //   5. Endpoint plugins    (org-scoped)  → id, name, icon, supportedModes
  //   6. Shared policy groups (env-scoped) → id, name, description, phase, apiType, policyId
  const api = null as ApiDetail | null; /* replace: query 1 */
  const rawPlans = null as { id: string; name: string; flows?: Flow[] }[] | null; /* replace: query 2 */
  const rawPolicies = null as PluginEntry[] | null; /* replace: query 3 */
  const entrypointPlugins = null as PluginEntry[] | null; /* replace: query 4 */
  const endpointPlugins = null as PluginEntry[] | null; /* replace: query 5 */
  const rawSpg = null as SharedPolicyGroupPolicy[] | null; /* replace: query 6 */
  const isLoading = false; /* replace: combine isLoading from all queries */
  const isError = false; /* replace: combine isError from all queries */

  const policies: readonly Policy[] = useMemo(
    () =>
      (rawPolicies ?? []).map((p) => ({
        id: p.id,
        name: p.name,
        icon: p.icon,
      })),
    [rawPolicies],
  );

  const plans: readonly Plan[] = useMemo(
    () => (rawPlans ?? []).map((p) => ({ id: p.id, name: p.name, flows: (p.flows ?? []) as readonly Flow[] })),
    [rawPlans],
  );

  const commonFlows: readonly Flow[] = useMemo(() => (api?.flows ?? []) as readonly Flow[], [api?.flows]);

  const entrypointsInfo: readonly ConnectorInfo[] = useMemo(
    () => (api && entrypointPlugins ? buildEntrypointsInfo(api, entrypointPlugins) : []),
    [api, entrypointPlugins],
  );

  const endpointsInfo: readonly ConnectorInfo[] = useMemo(
    () => (api && endpointPlugins ? buildEndpointsInfo(api, endpointPlugins) : []),
    [api, endpointPlugins],
  );

  const sharedPolicyGroups: readonly SharedPolicyGroupPolicy[] = useMemo(() => rawSpg ?? [], [rawSpg]);

  return {
    apiType: (api?.type ?? 'PROXY') as ApiType,
    policies,
    sharedPolicyGroups,
    plans,
    commonFlows,
    entrypointsInfo,
    endpointsInfo,
    flowExecution: api?.flowExecution ?? { mode: 'DEFAULT' },
    apiDetail: api,
    isLoading,
    isError,
  };
}
