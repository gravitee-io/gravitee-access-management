// Snippet: Policy Studio integration
//
// Use when embedding Policy Studio in an API management page.
// The host owns API data and persistence; PolicyStudio renders the full UI.
//
// Replace {PLACEHOLDERS} with your actual values.
// See Storybook "Policy Studio/PolicyStudio" for live demos.

import { useCallback, useMemo } from 'react';
import { PolicyStudio } from '@gravitee/graphene-policy-studio';
import type { ApiType, Policy, SaveOutput } from '@gravitee/graphene-policy-studio';

export function ApiPolicyStudioPage({ apiType }: { apiType: ApiType }) {
  const policies = useMemo(() => [] as const /* replace with policies from API */, []);
  const plans = useMemo(() => [] as const /* replace with plans from API */, []);
  const commonFlows = useMemo(() => [] as const /* replace with commonFlows from API */, []);
  const sharedPolicyGroups = useMemo(() => [] as const /* replace with shared policy groups */, []);
  const entrypointsInfo = useMemo(() => [] as const /* replace with entrypointsInfo */, []);
  const endpointsInfo = useMemo(() => [] as const /* replace with endpointsInfo */, []);

  const onSave = useCallback(
    async (_output: SaveOutput) => {
      // SaveOutput is a delta — only changed fields are present:
      //   output.commonFlows?    → full list of current common flows (when any changed/deleted)
      //   output.plansToUpdate?  → only affected plans, each with its full flow list
      //   output.flowExecution?  → updated execution config (when mode/matchRequired changed)
      //
      // Return a Promise so Policy Studio can show error feedback:
      //   - On success: saving indicator runs for 5 s then resets.
      //   - On rejection: Save button turns destructive, tooltip shows error.message.
      //
      // Most REST APIs have no PATCH endpoint — use GET-then-PUT to merge the delta:
      //
      //   if (output.commonFlows || output.flowExecution) {
      //     const current = await api.getApiDetail(apiId);
      //     const merged = { ...current };
      //     if (output.commonFlows)   merged.flows         = output.commonFlows;
      //     if (output.flowExecution) merged.flowExecution  = output.flowExecution;
      //     await api.updateApi(apiId, merged);
      //   }
      //
      //   if (output.plansToUpdate) {
      //     await Promise.all(
      //       output.plansToUpdate.map(async (plan) => {
      //         const current = await api.getPlan(apiId, plan.id);
      //         await api.updatePlan(apiId, plan.id, { ...current, flows: plan.flows });
      //       }),
      //     );
      //   }
      //
      //   // Invalidate relevant cache keys after success.
    },
    [
      /* replace with your dependencies */
    ],
  );

  const onFetchPolicySchema = useCallback(async (_policy: Policy) => {
    /* replace: GET JSON schema for policy.id */
    return {};
  }, []);

  const onFetchPolicyDocumentation = useCallback(async (_policy: Policy) => {
    /* replace: GET docs (string or PolicyDocumentation) for policy.id */
    return '';
  }, []);

  return (
    <PolicyStudio
      apiType={apiType}
      policies={policies}
      sharedPolicyGroups={sharedPolicyGroups}
      plans={plans}
      commonFlows={commonFlows}
      entrypointsInfo={entrypointsInfo}
      endpointsInfo={endpointsInfo}
      flowExecution={{ mode: 'DEFAULT' }}
      onSave={onSave}
      onFetchPolicySchema={onFetchPolicySchema}
      onFetchPolicyDocumentation={onFetchPolicyDocumentation}
    />
  );
}
