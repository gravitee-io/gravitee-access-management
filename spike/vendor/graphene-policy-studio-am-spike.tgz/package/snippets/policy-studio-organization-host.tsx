// Snippet: Policy Studio at organization scope (platform flows, spec 22)
//
// Use when embedding Policy Studio on the Organization → Policies page.
// Platform flows are HTTP request/response policies the gateway applies
// around EVERY HTTP API in the organization.
//
// Replace {PLACEHOLDERS} with your actual values.
// See Storybook "Policy Studio/PolicyStudio → Organization" for a live demo.

import { useCallback, useMemo } from 'react';
import { PolicyStudio } from '@gravitee/graphene-policy-studio';
import type { Policy, SaveOutput } from '@gravitee/graphene-policy-studio';

export function OrganizationPoliciesPage() {
  // The organization persists flows in the v2 wire shape. Mapping it to the
  // studio's v4 `Flow` is the host's responsibility (spec 22.3):
  //   path-operator.path/.operator → selectors[HTTP].path/.pathOperator
  //   methods                      → selectors[HTTP].methods
  //   condition                    → selectors[CONDITION].condition
  //   pre / post                   → request / response
  //   consumers[{consumerType:'TAG', consumerId}] → tags: [consumerId]
  const commonFlows = useMemo(() => [] as const /* replace with mapped organization flows */, []);

  // GET {org.baseURL}/configuration/tags
  const organizationTags = useMemo(() => [] as const /* replace with the organization's sharding tags */, []);

  // Policy list for platform scope; schemas may arrive pre-expanded.
  const policies = useMemo(() => [] as const /* replace with policies */, []);

  const onSave = useCallback(
    async (_output: SaveOutput) => {
      // At organization scope, SaveOutput carries `commonFlows` and/or
      // `flowExecution` only — `plansToUpdate` is never emitted.
      //
      // DATA-LOSS HAZARD: the organization update API replaces flows with the
      // payload; an absent or null `flows` deletes every platform flow. Always
      // GET the organization, merge, and PUT the FULL entity with the FULL
      // ordered flow list:
      //
      //   const org = await api.getOrganization();
      //   const merged = { ...org };
      //   if (output.commonFlows)   merged.flows    = output.commonFlows.map(toV2Flow);
      //   if (output.flowExecution) merged.flowMode = output.flowExecution.mode;
      //   await api.updateOrganization(merged);
      //
      // Saving deploys to every gateway — confirm with the user first
      // ("Deploy the policies?") before issuing the PUT; the studio simply
      // awaits this promise.
      //
      // If the user CANCELS the confirmation, do not resolve normally: a
      // resolved promise makes the studio treat the save as successful and
      // reset its saving state while nothing was persisted. Throw instead so
      // the studio keeps its dirty state (the Save button will surface the
      // error message, so throw something explicit like
      // `new Error('Deployment cancelled')`).
    },
    [
      /* replace with your dependencies */
    ],
  );

  const onFetchPolicySchema = useCallback(async (_policy: Policy) => {
    /* replace: GET JSON schema for policy.id (apiProtocolType=HTTP_PROXY) */
    return {};
  }, []);

  const onFetchPolicyDocumentation = useCallback(async (_policy: Policy) => {
    /* replace: GET documentation for policy.id (apiProtocolType=HTTP_PROXY) */
    return { content: '', language: 'MARKDOWN' as const };
  }, []);

  return (
    <PolicyStudio
      apiType="PROXY"
      scope="ORGANIZATION"
      policies={policies}
      sharedPolicyGroups={[]}
      plans={[]}
      commonFlows={commonFlows}
      entrypointsInfo={[]}
      endpointsInfo={[]}
      organizationTags={organizationTags}
      flowExecution={{ mode: 'DEFAULT' /* replace with organization.flowMode */ }}
      readOnly={false /* replace: true when the user lacks the update permission */}
      onSave={onSave}
      onFetchPolicySchema={onFetchPolicySchema}
      onFetchPolicyDocumentation={onFetchPolicyDocumentation}
    />
  );
}
