# Using Policy Studio

> **Scope:** These rules only apply when working with `@gravitee/graphene-policy-studio`. Do not apply them to unrelated parts of the codebase.

Policy Studio is the Graphene module for editing API flows, plans, and policy steps. The host application owns API data and persistence; the library provides the complete studio UI via a single `<PolicyStudio />` component.

Browse the live component catalog in this package's Storybook (local: `yarn workspace @gravitee/graphene-policy-studio storybook`).

## Quick start

> **V4 APIs only.** The snippets and examples below target V4 API definitions. V2 APIs use a different flow model (`pathOperator` + `pre`/`post` instead of `selectors` + phase steps) and require a host-side adapter to convert to V4 shapes. Pass `readOnly={true}` for V2 APIs.

```tsx
import { PolicyStudio } from '@gravitee/graphene-policy-studio';

function ApiPolicyStudioPage() {
  return (
    <PolicyStudio
      apiType="PROXY"
      policies={policies}
      plans={plans}
      commonFlows={commonFlows}
      sharedPolicyGroups={sharedPolicyGroups}
      entrypointsInfo={entrypointsInfo}
      endpointsInfo={endpointsInfo}
      flowExecution={{ mode: 'DEFAULT' }}
      onSave={handleSave}
      onFetchPolicySchema={fetchSchema}
      onFetchPolicyDocumentation={fetchDocs}
    />
  );
}
```

That's it. `PolicyStudio` renders the full UI (sidebar, info bar, flow canvas) and manages all internal state. The host supplies data and three callbacks.

```mermaid
flowchart TB
  Host[Host app]
  PS["PolicyStudio"]
  Layout[Layout + sidebar + canvas]
  Host -->|"data + onSave + fetchers"| PS
  PS --> Layout
```

## Package exports

| Export | What it is |
| ------ | ---------- |
| `@gravitee/graphene-policy-studio` | Single entry: `PolicyStudio`, provider, context hook, domain types, phase mappings. |

**Named exports (main integration surface):**

| Symbol | Role |
| ------ | ---- |
| `PolicyStudio` | Full studio UI — primary consumer integration point |
| `PolicyStudioProps` | TypeScript props for `PolicyStudio` |
| `PolicyStudioProvider` | Context-only wrapper — for advanced use or sub-component stories |
| `usePolicyStudioContext` | Read studio data and cached fetchers from child components |
| `PolicyStudioLayout` | Layout shell (sidebar + info bar + canvas slots) |
| `FlowsSidebar`, `FlowsSidebarProps` | Sidebar component — used internally by `PolicyStudio` |
| `getFlowPhases`, `getProtocolType` | Map `ApiType` to flow phases and protocol |
| `API_TYPE_TO_PROTOCOL`, `FLOW_PHASES_BY_API_TYPE` | Static lookup tables |
| Domain types | `ApiType`, `Policy`, `Plan`, `Flow`, `SaveOutput`, `PolicyDocumentation`, etc. |

There are no subpath exports (e.g. no `@gravitee/graphene-policy-studio/context`). Import everything from the package root.

## Dependencies (what the host needs)

| Dependency | Required | Notes |
| ---------- | -------- | ----- |
| `react`, `react-dom` | Yes (^19) | Provider and UI components |
| `@gravitee/graphene-core` | Yes (^2) | Shared primitives used by studio UI (`cn`, `ScrollArea`, `Prose`, ...) |
| `tailwindcss` | Optional (^4) | Only needed if the host runs its own Tailwind pipeline (Tier 2) |

Install:

```bash
yarn add @gravitee/graphene-policy-studio @gravitee/graphene-core react react-dom
```

The host should also follow [Graphene integration](../core/USAGE_GUIDE.md) (fonts, styles, and optionally Tailwind theme) so studio UI matches the design system.

## Styling prerequisites

**No separate CSS import is needed for the policy studio.** The standard Graphene Tier 1 imports are sufficient:

```ts
import '@gravitee/graphene-core/fonts';
import '@gravitee/graphene-core/styles';
```

All layout, theming, and typography classes used by policy-studio are covered by core's pre-built CSS bundle. There is no `@gravitee/graphene-policy-studio/styles` entry.

### Parent height requirement

`PolicyStudio` uses a CSS Grid layout that relies on `h-full`. The host must provide an ancestor element with an explicit height for the grid to fill the viewport:

```tsx
<div className="h-svh">
  <PolicyStudio {...props} />
</div>
```

Any height constraint works: `h-svh`, `h-screen`, or `flex-1 min-h-0` inside a flex parent.

### Full-bleed layout inside `AppLayout`

When `PolicyStudio` is rendered inside a Graphene `AppLayout`, the default content padding clips the studio grid. Set `contentVariant: 'full-bleed'` to remove it:

```tsx
// Direct prop
<AppLayout contentVariant="full-bleed">
  <PolicyStudio {...props} />
</AppLayout>

// Or via useLayoutConfig (module federation / nested routes)
useLayoutConfig({ contentVariant: 'full-bleed' }, []);
```

Without this, the studio renders incorrectly inside the shell — the sidebar and canvas will be inset rather than spanning edge-to-edge.

### Tier 2 (optional Tailwind pipeline)

For hosts that run their own Tailwind build and want full coverage of any future interactive variant classes, add a `@source` directive that scans the policy-studio distribution:

```css
@source '../node_modules/@gravitee/graphene-policy-studio/dist/**/*.{js,mjs}';
```

This is not required for the studio to render correctly — it only picks up hover/focus variant combinations that may be added in future releases.

## `PolicyStudio` props

### Required props

| Prop | Type | Role |
| ---- | ---- | ---- |
| `apiType` | `ApiType` | Drives flow phases and protocol (`PROXY`, `MESSAGE`, `MCP_PROXY`, ...) |
| `policies` | `readonly Policy[]` | Policy catalog for the API |
| `sharedPolicyGroups` | `readonly SharedPolicyGroupPolicy[]` | Shared policy groups available to the API |
| `plans` | `readonly Plan[]` | Plans and their flows |
| `commonFlows` | `readonly Flow[]` | API-level flows |
| `entrypointsInfo` | `readonly ConnectorInfo[]` | Entrypoint connectors (used for connector filtering) |
| `endpointsInfo` | `readonly ConnectorInfo[]` | Endpoint connectors |
| `flowExecution` | `FlowExecution` | Flow matching mode and `matchRequired` |
| `onSave` | `(output: SaveOutput) => Promise<void> \| void` | Persist studio changes (delta only). Return a `Promise` to enable error feedback. |
| `onFetchPolicySchema` | `(policy: Policy) => Promise<unknown>` | Host API: JSON schema for policy config |
| `onFetchPolicyDocumentation` | `(policy: Policy) => Promise<string \| PolicyDocumentation>` | Host API: policy docs |

### Optional props

| Prop | Default | Role |
| ---- | ------- | ---- |
| `readOnly` | `false` | Disable editing in the studio |
| `loading` | `false` | Show loading state |
| `scope` | `'API'` | Owner of the flows. `'ORGANIZATION'` renders the platform-flows studio (see below) |
| `organizationTags` | `[]` | Sharding tags offered by the flow form's Tags field. Only read at `ORGANIZATION` scope |
| `resources` | `[]` | Resources configured on the API, offered by `resource-type` config fields |
| `defaultSelectedFlowId` | — | VM id of the flow to select initially |
| `className` | — | CSS class on the root layout element |

### Organization scope (platform flows)

Pass `scope="ORGANIZATION"` to host the studio on the organization's platform flows — the
request/response policies the gateway applies around **every** API it serves, before and after
that API's own flows. Rules (spec section 22):

- `apiType` must be `'PROXY'`; any other value throws `"Organization scope supports PROXY only"`.
  This describes the flow model — request and response phases, no plans — not the API types the
  flows reach at runtime.
- The policy catalog widens: a policy qualifies as soon as **any** protocol declares the phase, and
  a policy declaring no compatibility at all is kept. Policies that only run on native Kafka fall
  out on their own, since they never declare REQUEST or RESPONSE.
- Pass `plans`, `sharedPolicyGroups`, `entrypointsInfo`, `endpointsInfo`, and `resources` as empty
  arrays; `commonFlows` carries the organization's flows in persisted order.
- `flowExecution` carries `{ mode }` only — `matchRequired` does not exist at organization level and
  the setting is hidden.
- The flow form gains a **Tags** multi-select fed by `organizationTags`; tag IDs persist on `Flow.tags`.
- `onSave` receives `commonFlows` and/or `flowExecution` only, with `commonFlows` always the **full
  ordered list**. The organization update API replaces flows with the payload, so never send a delta,
  and confirm with the user before persisting — saving deploys to every gateway.
- The organization's wire format is the v2 flow shape (`path-operator`, `pre`/`post`,
  `consumers` → `tags`); mapping it to the studio's `Flow` is the host's responsibility.

> **Note on the V2 read-only rule above:** "Pass `readOnly={true}` for V2 APIs" concerns a V2 **API's**
> flows. The organization definition is v2-shaped on the wire but governs v4 HTTP traffic too — it is
> fully editable at organization scope; `readOnly` there should reflect the user's permissions instead.

### Performance

- **Memoize** array props (`policies`, `plans`, `commonFlows`, ...) and `onSave` with `useMemo` / `useCallback`. They feed into the internal context `useMemo` dependency array; new references every render force all consumers to re-render.
- **Fetcher callbacks** (`onFetchPolicySchema`, `onFetchPolicyDocumentation`) are captured on **first mount** inside the provider. Keep them referentially stable for the lifetime of the component, or ensure they close over values that do not change.

### To implement

Copy the snippet from `snippets/policy-studio-provider-host.tsx` and replace the placeholder comments with your API data and handlers. See Storybook **Policy Studio/PolicyStudio** for live demos with different API types.

## Advanced: `PolicyStudioProvider` + custom UI

For consumers who need full control over the UI layout, use `PolicyStudioProvider` directly with `children`:

```tsx
import {
  PolicyStudioProvider,
  PolicyStudioLayout,
  FlowsSidebar,
  usePolicyStudioContext,
} from '@gravitee/graphene-policy-studio';

<PolicyStudioProvider {...providerProps}>
  <PolicyStudioLayout
    sidebar={<FlowsSidebar />}
    infoBar={<CustomInfoBar />}
  >
    <CustomCanvas />
  </PolicyStudioLayout>
</PolicyStudioProvider>
```

This is not required for most consumers. Use `PolicyStudio` instead.

## Context API (`usePolicyStudioContext`)

Call from any descendant of `PolicyStudioProvider` (or `PolicyStudio`):

```tsx
function PolicyConfigPanel() {
  const { fetchPolicySchema, policies, readOnly, onSave } = usePolicyStudioContext();
  // ...
}
```

**Exposed on context:**

- All data props from the provider (`apiType`, `policies`, `plans`, `commonFlows`, ...)
- `readOnly`, `loading`
- `onSave` — same callback the host passed in
- `fetchPolicySchema` — cached wrapper (not the raw host callback)
- `fetchPolicyDocumentation` — cached, normalized wrapper

Throws if used outside `PolicyStudioProvider`.

## Fetcher contract

### Policy schema (`onFetchPolicySchema` -> `fetchPolicySchema`)

- Host returns `Promise<unknown>` (typically a JSON Schema object).
- Cached **per `policy.id`** for the lifetime of the provider mount.
- **Concurrent** calls for the same id share one in-flight promise.
- **Rejected** promises are **evicted** from the cache; the next call retries the host fetcher (transient network errors are not permanently cached).

Use `fetchPolicySchema` from context in UI — do not call the host callback directly from children.

### Policy documentation (`onFetchPolicyDocumentation` -> `fetchPolicyDocumentation`)

- Host may return a raw `string` (treated as ASCIIDOC: `{ content, language: 'ASCIIDOC' }`) or a `PolicyDocumentation` object.
- Empty content and fetch **errors** resolve to a standard placeholder: `{ content: 'No documentation available.', language: 'MARKDOWN' }`.
- Cached per `policy.id` like schema; concurrent deduplication applies.

Use `fetchPolicyDocumentation` from context — it always returns `Promise<PolicyDocumentation>`.

## Save contract

`onSave` receives a **`SaveOutput` delta** — only the fields the user changed are included. The host merges this delta into its API model and persists.

```ts
type SaveOutput = {
  readonly commonFlows?: readonly Flow[];
  readonly flowExecution?: FlowExecution;
  readonly plansToUpdate?: readonly Plan[];
};
```

### What triggers the Save button

The Save button is **disabled** by default and becomes enabled when any of the following occur:

- A flow is added, edited, deleted, duplicated, reordered, or enabled/disabled.
- Steps within a flow are added, removed, reordered, duplicated, toggled, or reconfigured.
- The flow execution configuration (`mode` or `matchRequired`) is changed.

Save is also **blocked** when any step has invalid configuration — the button stays disabled and a tooltip shows the error count.

### What each `SaveOutput` field contains

| Field | Included when | Value |
| ----- | ------------- | ----- |
| `commonFlows` | Any non-plan flow was changed or deleted | The **full list** of current non-plan flows (not just the changed ones). For `MCP_PROXY`, this includes common and MCP method flows merged together. |
| `plansToUpdate` | Any plan has a changed or deleted flow | Only the **affected plans**, each containing its **full list** of current flows. Unchanged plans are omitted. |
| `flowExecution` | Flow execution mode or `matchRequired` changed | The updated `FlowExecution` object. |

If nothing changed, `onSave` is never called (the button stays disabled).

### Delta semantics — examples

**Scenario: edit a step in one common flow**

```ts
{
  commonFlows: [/* ALL current common flows, not just the edited one */]
}
// plansToUpdate and flowExecution are absent — they didn't change.
```

**Scenario: delete a flow from the "Gold" plan**

```ts
{
  plansToUpdate: [
    { id: 'plan-gold', name: 'Gold', flows: [/* remaining flows in Gold */] }
  ]
}
// Other plans are omitted. commonFlows is absent.
```

**Scenario: change flow execution mode + edit a common flow**

```ts
{
  commonFlows: [/* ALL current common flows */],
  flowExecution: { mode: 'BEST_MATCH', matchRequired: true }
}
```

### Change and deletion detection

- **Changed flows** are tracked via an internal `_hasChanged` flag. Any mutation (edit, toggle, step change, reorder, etc.) marks the flow as changed.
- **Deleted flows** are detected by comparing the current set of flow IDs against the initial set. If a flow ID is missing, the group is included in the delta with the remaining flows.
- **Internal VM fields** (`_id`, `_hasChanged`, `_parentFlowGroupName`) are stripped from all flows before they appear in `SaveOutput`. The output contains clean `Flow` objects ready for persistence.

### GET-then-PUT merge pattern

`SaveOutput` is a **delta** by design — it contains only what changed. Most management APIs have no PATCH endpoint, so the host must GET the current entity, merge the delta fields, and PUT the full object back. For plans, this means a `Promise.all` over each affected plan.

See the `onSave` comment in `snippets/policy-studio-provider-host.tsx` for the full pattern.

### Async save and error handling

`onSave` can return either `void` (fire-and-forget) or `Promise<void>` (async with error feedback):

```tsx
// Async with error handling (recommended)
const onSave = useCallback(async (output: SaveOutput) => {
  // 1. GET current API / plan entities
  // 2. Merge delta fields from output
  // 3. PUT merged entities
  // 4. Invalidate cache keys
}, []);
```

When `onSave` returns a `Promise`:

- **Success:** The saving indicator runs for 5 seconds as usual, then resets.
- **Rejection:** The Save button turns **destructive** (red) and a tooltip shows the error message. `canSave` re-enables so the user can retry. The error clears automatically on the next save attempt or when the host pushes new data.

The error message is extracted from the rejection value: if it is an `Error` instance, `error.message` is used; otherwise `'Save failed'` is shown as a fallback.

### Post-save behavior

- The Save button is disabled immediately after saving.
- A `saving` state is held for 5 seconds (configurable internally) after a successful save.
- If save fails (rejected promise), saving resets immediately and `canSave` re-enables.
- When the host pushes new data (updating `plans`, `commonFlows`, or `flowExecution` props), the saving state and any error reset; the cycle starts fresh.

Saving does not clear schema or documentation caches.

## Domain helpers

Align host payloads with studio rules:

```tsx
import { getFlowPhases, getProtocolType, API_TYPE_TO_PROTOCOL } from '@gravitee/graphene-policy-studio';

const phases = getFlowPhases('PROXY'); // ['REQUEST', 'RESPONSE']
const protocol = getProtocolType('MESSAGE'); // 'HTTP_MESSAGE'
```

| Helper | Use |
| ------ | --- |
| `getFlowPhases(apiType)` | Which phases to show in the canvas for this API type |
| `getProtocolType(apiType)` | Protocol key used for policy compatibility |
| `FLOW_PHASES_BY_API_TYPE` | Static phase list per API type |
| `API_TYPE_TO_PROTOCOL` | Static protocol mapping |

## Key types

| Type | Purpose |
| ---- | ------- |
| `ApiType` | `PROXY`, `MESSAGE`, `MCP_PROXY`, `LLM_PROXY`, `NATIVE`, `A2A_PROXY` |
| `Policy` | Catalog entry (`id`, `name`, optional `category`, `icon`, ...) |
| `Flow` | Selectors + phase steps (`request`, `response`, `connect`, ...) |
| `Plan` | `id`, `name`, `flows` |
| `Step` | Policy step on a flow (`policy`, `configuration`, `enabled`, ...) |
| `SaveOutput` | Delta passed to `onSave` |
| `PolicyDocumentation` | `{ content: string; language: 'MARKDOWN' \| 'ASCIIDOC' }` |

Import the named types from `@gravitee/graphene-policy-studio` for full TypeScript shapes in your host app.

## Common mistakes to avoid

- Forgetting to import **`@gravitee/graphene-core/styles`** — the studio UI will appear unstyled or broken (the grid stacks vertically instead of rendering the sidebar + content layout).
- Passing **inline arrays** (`policies={[...]}`) or **inline callbacks** without `useMemo` / `useCallback` — causes unnecessary context updates.
- Recreating **fetcher functions** on every render while expecting updated closures — fetchers are frozen at first mount.
- Calling **`onFetchPolicySchema`** from children instead of **`fetchPolicySchema`** from context — bypasses cache and deduplication.
- Treating documentation fetch results as always `string` — use context's normalized `PolicyDocumentation`.
- Expecting **`onSave`** to receive the full API definition — only `SaveOutput` fields the user changed.
- Not providing an **ancestor with explicit height** around `<PolicyStudio />` — the grid collapses to zero height.

## Snippets

| File | When to use |
| ---- | ----------- |
| `snippets/policy-studio-provider-host.tsx` | First integration: single `PolicyStudio` component with memoized host callbacks and GET-then-PUT save pattern |
| `snippets/policy-studio-data-layer.tsx` | Data-fetching layer: parallel queries, `buildEntrypointsInfo` / `buildEndpointsInfo` transforms, loading gate (V4 APIs) |
| `snippets/policy-studio-organization-host.tsx` | Organization scope: platform flows host with the v2 wire mapping and the full-list save rule |

Snippets ship in the npm package under `node_modules/@gravitee/graphene-policy-studio/snippets/`. They are copy-paste templates, not importable modules.
